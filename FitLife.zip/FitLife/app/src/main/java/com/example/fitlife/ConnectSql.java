package com.example.fitlife;

import static java.sql.DriverManager.println;
import java.sql.DriverManager

public class ConnectSql {
    fun main() {
        val url = "jdbc:mysql://localhost:3307/fitlife"
        val user = "usuario"
        val password =

        DriverManager.getConnection(url, user, password).use { connection ->
                println("Conexión exitosa a la base de datos")

        }
    }

}
